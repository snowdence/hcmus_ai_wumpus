# Folder Structure

    - src: Source code
    - map_sample: 10 maps
    - 18127004_18127027_18127263.pdf : report
    - Readme.md : Guild to use

# How to use

cd "src"
python wumpus.py

# Change map

- Copy data of map to src/maps/map_10_10.txt
- Run wumpus.py

# Official Github Repository

https://github.com/snowdence/hcmus_ai_wumpus

# Contributors

18127004 - Nguyen Vu Thu Hien
18127027 - Tran Minh Duc
18127263 - Dinh Phi Long
