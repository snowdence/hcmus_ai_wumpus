class EScreenState:
    MENU = 1
    GROUP = 2
    PLAY_GAME = 3
