class Action:
    actionCode = -1

    def __init__(self, code: int):
        self.actionCode = code
