class State:
    def __init__(self):
        pass

    def isEquals(self, state):
        pass
