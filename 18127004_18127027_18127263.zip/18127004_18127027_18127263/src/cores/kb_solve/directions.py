class DIRECTIONS:
    UP = (0, 1)  # North UP South DOWN West LEFT EAST RIGHT
    DOWN = (0, -1)
    RIGHT = (1, 0)
    LEFT = (-1, 0)

    NORTH = (0, 1)
    SOUTH = (0, -1)
    EAST = (1, 0)
    WEST = (-1, 0)
    l_directions = [UP, DOWN, RIGHT, LEFT]
    LM_DIRECTIONS = [NORTH, SOUTH, EAST, WEST]
