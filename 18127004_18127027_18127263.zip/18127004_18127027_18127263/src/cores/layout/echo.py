
def print_layout(self, wumpus_env):
    pass
