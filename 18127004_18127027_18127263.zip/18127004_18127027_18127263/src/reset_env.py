# try:
#     import setting
#     import gpath
#     from .wumpus.enviroment import WumpusWorldEnv
# except:
#     #sys.path.append(os.path.dirname(os.path.realpath(__file__)) + "/..")
#     # print(sys.path)
#     import setting
#     import gpath
#     from cores.wumpus.enviroment import WumpusWorldEnv
